#!/bin/bash
echo 'Running compiled C program'
