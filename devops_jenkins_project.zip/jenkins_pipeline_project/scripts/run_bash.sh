#!/bin/bash
echo 'Hello from Bash script'
