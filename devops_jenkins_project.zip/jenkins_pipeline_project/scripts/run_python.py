print('Hello from Python script')
