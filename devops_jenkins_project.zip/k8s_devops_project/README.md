# K8s DevOps Project
This contains manifests, Dockerfiles, and deployment instructions.